/* =========================================================
   script.js
   ไฟล์นี้ควบคุมการทำงานทั้งหมดของระบบจองคิวร้านตัดผม
   - เก็บ/อ่านข้อมูลคิวจาก localStorage
   - ตรวจสอบความถูกต้องของฟอร์ม (validation)
   - ตรวจสอบเวลาซ้ำในวันเดียวกัน
   - แสดงผลรายการคิวเป็นการ์ด พร้อม Badge สถานะ
   - ระบบค้นหา/กรองคิว และปุ่มล้างข้อมูลทั้งหมด
   ========================================================= */

// คีย์ที่ใช้เก็บข้อมูลใน localStorage
const STORAGE_KEY = "barberQueueList";

// ตัวแปรเก็บ element หลักที่ใช้บ่อย
const bookingForm = document.getElementById("bookingForm");
const queueListEl = document.getElementById("queueList");
const emptyStateEl = document.getElementById("emptyState");
const queueCountEl = document.getElementById("queueCount");

const filterDateEl = document.getElementById("filterDate");
const filterNameEl = document.getElementById("filterName");
const clearFilterBtn = document.getElementById("clearFilterBtn");
const clearAllBtn = document.getElementById("clearAllBtn");

/* ---------------------------------------------------------
   ฟังก์ชันจัดการ localStorage
   --------------------------------------------------------- */

// อ่านรายการคิวทั้งหมดจาก localStorage (คืนค่าเป็น array เสมอ)
function getQueueList() {
  const raw = localStorage.getItem(STORAGE_KEY);
  try {
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    // ถ้าข้อมูลใน localStorage เสียหาย ให้เริ่มต้นใหม่เป็น array ว่าง
    console.error("อ่านข้อมูลคิวผิดพลาด:", e);
    return [];
  }
}

// บันทึกรายการคิวทั้งหมดกลับลง localStorage
function saveQueueList(list) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(list));
}

/* ---------------------------------------------------------
   ฟังก์ชัน Validation
   --------------------------------------------------------- */

// ล้างข้อความ error ทั้งหมดในฟอร์มก่อนตรวจใหม่ทุกครั้ง
function clearErrors() {
  document.querySelectorAll(".error-text").forEach((el) => {
    el.textContent = "";
    el.classList.add("hidden");
  });
}

// แสดงข้อความ error ใต้ฟิลด์ที่ระบุ
function showError(fieldName, message) {
  const errorEl = document.querySelector(`[data-error-for="${fieldName}"]`);
  if (errorEl) {
    errorEl.textContent = message;
    errorEl.classList.remove("hidden");
  }
}

// ตรวจสอบข้อมูลฟอร์ม คืนค่าเป็น object ข้อมูล ถ้าผ่าน หรือ null ถ้าไม่ผ่าน
function validateForm(formData, existingList) {
  let isValid = true;
  clearErrors();

  const customerName = formData.get("customerName").trim();
  const phone = formData.get("phone").trim();
  const barber = formData.get("barber");
  const service = formData.get("service");
  const bookingDate = formData.get("bookingDate");
  const bookingTime = formData.get("bookingTime");

  // 1) เช็กไม่ให้กรอกข้อมูลว่าง
  if (!customerName) {
    showError("customerName", "กรุณากรอกชื่อ-สกุลลูกค้า");
    isValid = false;
  }
  if (!phone) {
    showError("phone", "กรุณากรอกเบอร์โทรศัพท์");
    isValid = false;
  } else if (!/^[0-9]{9,10}$/.test(phone)) {
    // ตรวจรูปแบบเบอร์โทรเบื้องต้น (ตัวเลข 9-10 หลัก)
    showError("phone", "เบอร์โทรศัพท์ไม่ถูกต้อง (ตัวเลข 9-10 หลัก)");
    isValid = false;
  }
  if (!barber) {
    showError("barber", "กรุณาเลือกช่างตัดผม");
    isValid = false;
  }
  if (!service) {
    showError("service", "กรุณาเลือกบริการ");
    isValid = false;
  }
  if (!bookingDate) {
    showError("bookingDate", "กรุณาเลือกวันที่");
    isValid = false;
  }
  if (!bookingTime) {
    showError("bookingTime", "กรุณาเลือกเวลา");
    isValid = false;
  }

  // 2) เช็กไม่ให้จองเวลาซ้ำในวันเดียวกัน (เช็กเฉพาะคิวที่ยังไม่ยกเลิก)
  if (isValid) {
    const isDuplicate = existingList.some(
      (item) =>
        item.bookingDate === bookingDate &&
        item.bookingTime === bookingTime &&
        item.barber === barber &&
        item.status !== "cancelled"
    );
    if (isDuplicate) {
      showError(
        "bookingTime",
        "ช่วงเวลานี้ของช่างที่เลือกถูกจองแล้ว กรุณาเลือกเวลาอื่น"
      );
      isValid = false;
    }
  }

  if (!isValid) return null;

  return {
    id: Date.now().toString(), // ใช้ timestamp เป็น id เฉพาะของแต่ละคิว
    customerName,
    phone,
    barber,
    service,
    bookingDate,
    bookingTime,
    status: "pending", // สถานะเริ่มต้นเสมอคือ "รอยืนยัน"
    createdAt: new Date().toISOString(),
  };
}

/* ---------------------------------------------------------
   ฟังก์ชันแสดงผลรายการคิว (Render)
   --------------------------------------------------------- */

// แปลงวันที่ ISO (YYYY-MM-DD) ให้อ่านง่ายขึ้นแบบไทย
function formatDateThai(dateStr) {
  if (!dateStr) return "-";
  const date = new Date(dateStr + "T00:00:00");
  return date.toLocaleDateString("th-TH", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });
}

// สร้าง HTML ของ Badge สถานะตามค่า status
function getStatusBadgeHtml(status) {
  if (status === "completed") {
    return `<span class="status-badge badge-completed">✅ เสร็จสิ้น</span>`;
  }
  // ค่าเริ่มต้นคือ "รอยืนยัน"
  return `<span class="status-badge badge-pending">🕒 รอยืนยัน</span>`;
}

// วาดรายการคิวทั้งหมดลงหน้าเว็บ โดยรับ list ที่ผ่านการกรองแล้ว
function renderQueueList(list) {
  queueListEl.innerHTML = ""; // ล้างของเดิมก่อนวาดใหม่

  if (list.length === 0) {
    emptyStateEl.classList.remove("hidden");
  } else {
    emptyStateEl.classList.add("hidden");
  }

  // เรียงลำดับตามวันที่และเวลาที่จอง (เร็วสุดไปช้าสุด)
  const sortedList = [...list].sort((a, b) => {
    const dateA = `${a.bookingDate} ${a.bookingTime}`;
    const dateB = `${b.bookingDate} ${b.bookingTime}`;
    return dateA.localeCompare(dateB);
  });

  sortedList.forEach((item) => {
    const isCompleted = item.status === "completed";

    const card = document.createElement("div");
    card.className = `queue-card border border-gray-200 rounded-xl p-4 flex flex-col gap-2 ${
      isCompleted ? "is-completed" : ""
    }`;
    card.dataset.id = item.id;

    card.innerHTML = `
      <div class="flex items-start justify-between">
        <div>
          <p class="font-semibold text-gray-800">${escapeHtml(item.customerName)}</p>
          <p class="text-sm text-gray-500">${escapeHtml(item.phone)}</p>
        </div>
        ${getStatusBadgeHtml(item.status)}
      </div>

      <div class="text-sm text-gray-600 space-y-1 mt-1">
        <p>💇 ช่าง: <span class="font-medium">${escapeHtml(item.barber)}</span></p>
        <p>🧴 บริการ: <span class="font-medium">${escapeHtml(item.service)}</span></p>
        <p>📅 วันที่: <span class="font-medium">${formatDateThai(item.bookingDate)}</span></p>
        <p>⏰ เวลา: <span class="font-medium">${escapeHtml(item.bookingTime)}</span></p>
      </div>

      <div class="flex gap-2 mt-2">
        <button
          class="complete-btn flex-1 text-sm bg-green-50 hover:bg-green-100 text-green-700 font-medium py-1.5 rounded-lg transition"
          ${isCompleted ? "disabled" : ""}
        >
          ${isCompleted ? "เสร็จสิ้นแล้ว" : "✔️ ทำรายการเสร็จสิ้น"}
        </button>
        <button
          class="cancel-btn flex-1 text-sm bg-red-50 hover:bg-red-100 text-red-600 font-medium py-1.5 rounded-lg transition"
        >
          ❌ ยกเลิกคิว
        </button>
      </div>
    `;

    queueListEl.appendChild(card);
  });

  queueCountEl.textContent = `(${list.length} รายการ)`;
}

// ป้องกัน HTML injection ง่ายๆ เวลานำข้อความผู้ใช้มาแสดงผล
function escapeHtml(str) {
  const div = document.createElement("div");
  div.textContent = str ?? "";
  return div.innerHTML;
}

/* ---------------------------------------------------------
   ฟังก์ชันกรอง/ค้นหารายการคิว
   --------------------------------------------------------- */

// อ่านค่าตัวกรองปัจจุบัน แล้วคืนค่ารายการที่ผ่านการกรองแล้ว
function getFilteredList() {
  const allList = getQueueList();
  const dateFilter = filterDateEl.value;
  const nameFilter = filterNameEl.value.trim().toLowerCase();

  return allList.filter((item) => {
    const matchDate = dateFilter ? item.bookingDate === dateFilter : true;
    const matchName = nameFilter
      ? item.customerName.toLowerCase().includes(nameFilter)
      : true;
    return matchDate && matchName;
  });
}

// เรียก renderQueueList ใหม่ตามตัวกรองปัจจุบัน (ใช้ทุกครั้งที่ข้อมูลหรือตัวกรองเปลี่ยน)
function refreshView() {
  renderQueueList(getFilteredList());
}

/* ---------------------------------------------------------
   Event Listeners
   --------------------------------------------------------- */

// เมื่อผู้ใช้กด "ยืนยันการจองคิว"
bookingForm.addEventListener("submit", function (e) {
  e.preventDefault(); // ป้องกันไม่ให้หน้าเว็บ refresh

  const formData = new FormData(bookingForm);
  const currentList = getQueueList();

  const newBooking = validateForm(formData, currentList);
  if (!newBooking) return; // ถ้า validate ไม่ผ่าน ให้หยุดทำงาน (error แสดงในฟอร์มแล้ว)

  currentList.push(newBooking);
  saveQueueList(currentList);

  bookingForm.reset();
  clearErrors();
  refreshView();
});

// จัดการปุ่ม "ทำรายการเสร็จสิ้น" และ "ยกเลิกคิว" ด้วย Event Delegation
// (ดักจับ event ที่ container แม่ แทนการผูก event ทีละการ์ด)
queueListEl.addEventListener("click", function (e) {
  const card = e.target.closest(".queue-card");
  if (!card) return;

  const id = card.dataset.id;
  let list = getQueueList();

  if (e.target.classList.contains("complete-btn")) {
    // อัปเดตสถานะเป็น "เสร็จสิ้น"
    list = list.map((item) =>
      item.id === id ? { ...item, status: "completed" } : item
    );
    saveQueueList(list);
    refreshView();
  }

  if (e.target.classList.contains("cancel-btn")) {
    // ยืนยันก่อนลบข้อมูลออกจากระบบ
    const confirmCancel = confirm("ต้องการยกเลิกคิวนี้ใช่หรือไม่?");
    if (!confirmCancel) return;

    list = list.filter((item) => item.id !== id);
    saveQueueList(list);
    refreshView();
  }
});

// ตัวกรอง: เมื่อพิมพ์ค้นหาชื่อ หรือเลือกวันที่ ให้ render ใหม่ทันที
filterDateEl.addEventListener("change", refreshView);
filterNameEl.addEventListener("input", refreshView);

// ปุ่มล้างตัวกรอง
clearFilterBtn.addEventListener("click", function () {
  filterDateEl.value = "";
  filterNameEl.value = "";
  refreshView();
});

// ปุ่มล้างข้อมูลทั้งหมด พร้อม Alert ยืนยันก่อนลบจริง
clearAllBtn.addEventListener("click", function () {
  const list = getQueueList();
  if (list.length === 0) {
    alert("ไม่มีข้อมูลคิวให้ล้าง");
    return;
  }

  const confirmClear = confirm(
    "⚠️ ต้องการล้างข้อมูลคิวทั้งหมดใช่หรือไม่? การกระทำนี้ไม่สามารถย้อนกลับได้"
  );
  if (!confirmClear) return;

  localStorage.removeItem(STORAGE_KEY);
  refreshView();
});

/* ---------------------------------------------------------
   เริ่มต้นทำงานเมื่อโหลดหน้าเว็บ
   --------------------------------------------------------- */
document.addEventListener("DOMContentLoaded", function () {
  refreshView();
});
